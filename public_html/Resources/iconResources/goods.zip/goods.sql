-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- 생성 시간: 17-08-02 15:21
-- 서버 버전: 10.1.9-MariaDB
-- PHP 버전: 7.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 데이터베이스: `gec`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `goods`
--

CREATE TABLE `goods` (
  `NO` int(10) NOT NULL,
  `NAME` varchar(50) NOT NULL,
  `KINDS` varchar(50) DEFAULT ' - ',
  `AMOUNT` int(10) DEFAULT NULL,
  `COMPANY` varchar(30) DEFAULT NULL,
  `PURCHASE_DATE` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `goods`
--

INSERT INTO `goods` (`NO`, `NAME`, `KINDS`, `AMOUNT`, `COMPANY`, `PURCHASE_DATE`) VALUES
(1, 'Honeywell Experion Demo System', ' PE2800 Server', 1, 'Dell', '2010.01'),
(2, 'Honeywell Experion Demo System', ' PE1600SC Server', 1, 'Dell', '2008.01'),
(3, 'Honeywell Experion Demo System', 'ExperionPKS Software', 2, 'Honeywell', '2012.05'),
(4, 'Honeywell Experion Demo System', ' ExperionLS Software', 2, 'Honeywell', '2012.07'),
(5, 'Honeywell Experion Demo System', ' ExperionHS Software', 1, 'Honeywell', '2012.02'),
(6, 'DCS(C300) Demo System (Full Set)', NULL, 1, 'Honeywell', '2012.09'),
(7, 'DCS(C200) Demo System (Full Set)', NULL, 2, 'Honeywell', '2010.02'),
(8, 'HC900 Hybrid Controller Demo Kit', NULL, 2, 'Honeywell', '2008.12'),
(9, 'S9000 Hybrid Controller Demo Kit', NULL, 5, 'Honeywell', '2005.12'),
(10, 'AB PLC5 Programmable Logic Controller Demo', NULL, 2, 'AllenBradley', '2002.07'),
(11, 'Glofa PLC with MasterK CPU & I/O Parts', NULL, 1, 'LSIS', '2003.05'),
(12, 'Design Equipment', ' PENTIUMIV 2.8GHz', 2, 'Dell', '2011.08'),
(13, 'Design Equipment', ' Plotter', 1, 'H.P', '2001.01'),
(14, 'Electric Control Equipment', ' Electronics Meter Simulator', 1, 'LGIS', '1999.09'),
(15, 'Electric Control Equipment', ' DC 110V Simulator', 1, 'SAMA', '1999.09'),
(16, 'Electric Control Equipment', ' P.T(AC220V/AC110V)1 Simulator', 1, 'Myoung Sung', '1999.09'),
(17, 'Measuring Equipment', ' Signal Calibrator', 1, 'YOKOGAWA', NULL),
(18, 'Measuring Equipment', ' Digital Multi Tester', 3, 'HIOKI', NULL),
(19, 'Measuring Equipment', ' Analog Multi Tester', 1, 'HYUNDAI', NULL),
(20, 'Programming Tools', ' Portable Notebook P.C', 5, 'Dell', NULL),
(21, 'Programming Tools', ' Portable Notebook P.C', 5, 'Dell', NULL),
(22, 'Programming Tools', ' Portable Notebook P.C', 5, 'Dell', NULL),
(23, 'Network Test Equipment', ' Communication Card', 2, 'Honeywell', '2000.02'),
(24, 'Network Test Equipment', ' Ethernet Transceiver(COAX to UTP)', 3, '3Com', '2000.02'),
(25, 'Network Test Equipment', ' Ethernet Transceiver(AUI to COAX)', 5, 'DLin', '2000.02'),
(26, 'Network Test Equipment', ' Ethernet Transceiver(AUI to UTP)', 1, 'Lantronix', '2000.02'),
(27, 'Network Test Equipment', ' Ethernet 광Transceiver, Single Type', 1, '3Com', '2000.04'),
(28, 'Network Test Equipment', ' Ethernet 광Transceiver, Dual Type', 1, '3Com', '2000.04'),
(29, 'Network Test Equipment', ' Ethernet Transceiver(광 to UTP)', 1, '3Com', '2000.04'),
(30, 'Network Test Equipment', ' Terminal Server(Performance2500)', 1, 'EMULEX', '2000.04'),
(31, 'Network Test Equipment', ' Optical Switching Hub', 2, '3Com', '2002.04'),
(32, 'Network Test Equipment', ' Protocol Converter', 4, 'GDS', '2002.01'),
(33, 'Network Test Equipment', ' PolyCAN/Canion DDC Unit Simulator', 1, 'Yamatake', '2002.03'),
(34, 'Electric, Instrument Control System  Equipments', NULL, 5, NULL, '2005.09');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
